create table contact(name varchar(120), number varchar(10), primary key(number));
